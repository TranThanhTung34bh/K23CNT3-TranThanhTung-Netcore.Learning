﻿namespace Ttt_Day5Model.Models.DataModels
{
    public class TttMember
    {
        public string TttMemberId { get; set; }
        public string TttUserName { get; set; }
        public string TttFullName { get; set; }
        public string TttPassword { get; set; }
        public string TttEmail { get; set; }
    }
}